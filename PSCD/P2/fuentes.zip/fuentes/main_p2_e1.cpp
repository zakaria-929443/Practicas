//------------------------------------------------------------------------------
// File:   main_p2_e1.cpp
// Author: PSCD
// Date:   septiembre 2026
// Coms:   Parte del práctica 2 de PSCD
//         Compilar mediante Makefile asociado
//------------------------------------------------------------------------------

#include <iostream>
#include <fstream>
#include <thread>
#include <string>
#include <chrono>

using namespace std;

const int N = 512;
const int N_BUSC = 8; // # de procesos buscadores

//------------------------------------------------------------------------------
// Pre: 0 <= i <= d <= N-1
// Post: result = Num alpha \in [i,d].value = v[alpha]
//------------------------------------------------------------------------------
void ocurrencias(const int v[N], const int i, const int d, const int value, int &result){

	// TODO
}

 
int main(int argc, char* argv[]) {

	// TODO

    return 0;
}
